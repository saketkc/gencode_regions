from setuptools import setup
setup(
      name="gtfBase",
      version="0.1",
      description="This is gtfBase",
      long_description="This is a long description of gtfBase",
      author="SaketKC",
      packages=['gtfBase'],
      install_requires=['gffutils', 'pybedtools']
)
