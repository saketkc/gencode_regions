import click
from simple_term_menu import TerminalMenu


@click.command()
@click.option("--path", "-p", type=str, help="path to the gtf file")
@click.option('--build', type=(str, int), help="provide the name of the"
                                               " species and the release from ensembl.\n"
                                               "Either path or build should be passed")
@click.option('--ty',
              type=click.Choice(['exons',
                                 'introns',
                                 'all',
                                 'none']))
@click.option('--interactive', default=False, help="Please select this if you want"
                                                   "an interactive environment")
def main(path, build, ty):
    """
    Hello this is the main function and please provide the following help command
    """
    if build is not None:
        name, release = build
        click.echo(f"name of the species {name} and the build id is {release}")

    if path is not None:
        click.echo(f"{path}")

    if ty is not None:
        click.echo(f"Hello {ty}")
    #
    if interactive:
        interact()


@click.command()
@click.option('--release', prompt='Please provide the build number')
def interact(release):
    ensembl_object = EnsemblDataManager(release)
    species_list = ensembl_object.get_list()
    species_menu = TerminalMenu(species_list, search_key=None)
    menu_entry_index = species_menu.show()
    print("You have selected %s..." % species_list[menu_entry_index])
    species_name = species_list[menu_entry_index]
    gtf_files = ensembl_object.get_gtf_list(species_name)

    gtf_file_name = gtf_files[0]
    if len(gtf_files) > 1:
        print("Choose one GTF file:")
        gtf_menu = TerminalMenu(gtf_files, search_key=None)
        gtf_entry_idx = gtf_menu.show()
        gtf_file_name = gtf_files[gtf_entry_idx]
    print('%s file will be used...' % gtf_file_name)
    print("Choose features:")
    feature_list = ["CDS", "exon", "intron", "five_prime_utr", "three_prime_utr"]
    feature_menu = TerminalMenu(
        feature_list, multi_select=True,
        show_multi_select_hint=True,
    )
    menu_entry_indices = feature_menu.show()
    print("You have selected following features: {0}"
          .format([feature_list[x] for x in menu_entry_indices]))
    # isme jo bhi hoga maan te ha list ka naam tanishq ha


if __name__ == '__main__':
    main()
