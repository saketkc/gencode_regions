"""
This module will contain constants used throughout the code.
"""
